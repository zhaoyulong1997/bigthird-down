# -*- coding: utf-8 -*-
"""
Created on Wed Oct 31 06:32:58 2018

@author: zhangzhaohui
"""
## 基于乳腺癌数据集分类
## 1.导入必要的算法包
#  (1)scikit-learn依赖于NumPy和 matplotlib。
#  导入python Numpy包(主要用于数组及数组操作，常用矩阵运算)，并以np为别名
#  Numpy含各种子包,想了解，可以：dir(np)
#  (2)导入python matplotlib包(2D图像的绘图工具包,常用语数据可视化)的子包pyplot
#  用于数据的可视化，并以plt为别名
#  了解该子包内容，可以dir(plt)
#  (3)数据分析模块
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

## (4)导入sklearn的模块的接口类 
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_curve, auc, roc_auc_score


## 2(1)数据获取地址；各种特征名称列表
data_web_address = "https://archive.ics.uci.edu/ml/machine-learning-databases/breast-cancer-wisconsin/breast-cancer-wisconsin.data"
column_names = ['radius',
                'texture',
                'perimeter',
                'area',
                'smoothness',
                'compactness',
                'concavity',
                'concave points', 
                'symmetry',
                'malignant']

## 2(2)去除最后一个特征名称
feature_names = column_names[:-1]

## 3 获取指定地址、指定属性的样本数据 699*10；读取各特征的数据类型
all_data = pd.read_csv(data_web_address , names=column_names)
all_data.dtypes


## 4.对原始样本数据进行调整；将相应属性类别置为1，或0
#    统计两种类别的样本数 0--458 1--241
#    changing the state of having cancer to 1, not having cancer to 0
all_data['malignant'] = all_data['malignant'].astype(np.int)
all_data['malignant'] = np.where(all_data['malignant'] == 4, 1,0) #4, and now 1 means malignant
all_data['malignant'].value_counts()

## 5.提取all_data数据的不同部分，构成样本集的输入部分、及类别标号
X = all_data[[col for col in feature_names if col != 'compactness']]
y = all_data.malignant

## 6.数据集划分为：训练集、测试集
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=7,stratify=y)


## 7.以默认方式初始logistic分类模型；学习模型；对测试样本进行后验概率预测
lr = LogisticRegression()
lr.fit(X_train,y_train)
y_pred_proba = lr.predict_proba(X_test)


## 8. 基于测试样本集关于第1类的预测概率，获取假阳性率、真阳性率、阈值序列；
# 绘制ROC曲线，估计AUC值
fpr, tpr, ths = roc_curve(y_test, y_pred_proba[:,1])
auc_score = auc(fpr,tpr)
plt.plot(fpr,tpr,label="AUC Score:" + str(auc_score))
plt.xlabel('fpr',fontsize='15')
plt.ylabel('tpr',fontsize='15')
plt.legend(loc='best')
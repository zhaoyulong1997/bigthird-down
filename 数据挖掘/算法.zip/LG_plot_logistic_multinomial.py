"""
====================================================
Plot multinomial and One-vs-Rest Logistic Regression
====================================================

Plot decision surface of multinomial and One-vs-Rest Logistic Regression.
The hyperplanes corresponding to the three One-vs-Rest (OVR) classifiers
are represented by the dashed lines.
"""
print(__doc__)
# Authors: Tom Dupre la Tour <tom.dupre-la-tour@m4x.org>
# License: BSD 3 clause

## 二维特征空间，基于Logistic Regression模型的多类别分类
## 1.导入必要的算法包
## (1)scikit-learn依赖于NumPy和 matplotlib。
#     导入python Numpy包(主要用于数组及数组操作，常用矩阵运算)，并以np为别名
#      Numpy含各种子包,想了解，可以：dir(np)
#  (2)导入python matplotlib包(2D图像的绘图工具包,常用语数据可视化)的子包pyplot
#     用于数据的可视化，并以plt为别名，了解该子包内容，可以dir(plt)
import numpy as np
import matplotlib.pyplot as plt

## (3)由sklearn的linear_model模块，导入LogisticRegression类
#  (4)导入datasets模块的make_blobs，用于高斯分布的样本数据随机生成   
#     见1311页sklearn.datasets.make_blobs
from sklearn.datasets import make_blobs
from sklearn.linear_model import LogisticRegression

## 2(1)初始化二维特征空间，三个类别中心
#   随机生成满足生态分布的三个类别样本数据 make 3-class dataset for classification
#   总样本数1000
# sklearn.datasets.make_blobs(n_samples=100, n_features=2, centers=3, 
#                             cluster_std=1.0,center_box=(-10.0, 10.0), 
#                             shuffle=True, random_state=None)

centers = [[-5, 0], [0, 1.5], [5, -1]]
X, y = make_blobs(n_samples=1000, centers=centers, random_state=40)

## 2(2)对生成的X数据集进行变换,变换矩阵[0.4.0.2;-0.4.1.2]
transformation = [[0.4, 0.2], [-0.4, 1.2]]
X = np.dot(X, transformation)

## 3.分别基于上述三类别样本集学习分类模型；模型使用；预测结果可视化
for multi_class in ('multinomial', 'ovr'):
    
    #(1)初始化指定形式的logistic分类模型；学习模型
    clf = LogisticRegression(solver='sag', max_iter=100, random_state=42,
                             multi_class=multi_class).fit(X, y)

    #(2)基于上述模型对训练集预测，得平均正确率 print the training scores
    print("training score : %.3f (%s)" % (clf.score(X, y), multi_class))

    #(3)特征空间网格化，得样本点-- create a mesh to plot in
    h = .02  # step size in the mesh
    x_min, x_max = X[:, 0].min() - 1, X[:, 0].max() + 1
    y_min, y_max = X[:, 1].min() - 1, X[:, 1].max() + 1
    xx, yy = np.meshgrid(np.arange(x_min, x_max, h),
                         np.arange(y_min, y_max, h))

    #(4)特征空间网格点的决策
    # Plot the decision boundary. For that, we will assign a color to each
    # point in the mesh [x_min, x_max]x[y_min, y_max].
    
    Z = clf.predict(np.c_[xx.ravel(), yy.ravel()])
    
    #(5) 以等高线的方式可视化。Put the result into a color plot
    Z1 = Z.reshape(xx.shape)
    plt.figure()
    plt.contourf(xx, yy, Z1, cmap=plt.cm.Paired)
    plt.title("Decision surface of LogisticRegression (%s)" % multi_class)
    plt.axis('tight')

    #(6) Plot also the training points
    colors = "bry" #颜色表[蓝，红，黄]
    for i, color in zip(clf.classes_, colors):
        idx = np.where(y == i)
        plt.scatter(X[idx, 0], X[idx, 1], c=color, cmap=plt.cm.Paired,
                    edgecolor='black', s=20)

    #(7) Plot the three one-against-all classifiers
    # 横轴区间；纵轴区间
    xmin, xmax = plt.xlim()
    ymin, ymax = plt.ylim()
    
    # 二维特征空间，3个两类别分类模型的特征权向量 3行*2列、偏置量3行*1
    coef = clf.coef_
    intercept = clf.intercept_

    # (8)定义：分类超平面(分类边界)的绘制函数
    #    参数c--分类模型序号,参数color-绘制颜色
    #    分类边界方程：x0*coef0+x1*xoef1+b=0
    #    该分类边界线与x=xmin,x=xmax的交点分别为:
    #    (xmin,(-b-xmin*coef0)/coef1)
    #    (xmax,(-b-xmax*coef0)/coef1)
    def plot_hyperplane(c, color):
        def line(x0):
            return (-(x0 * coef[c, 0]) - intercept[c]) / coef[c, 1]
        plt.plot([xmin, xmax], [line(xmin), line(xmax)],
                 ls="--", color=color)

    # (9)基于上述定义，绘制三个边界线
    for i, color in zip(clf.classes_, colors):
        plot_hyperplane(i, color)

## 4.显示结果
plt.show()

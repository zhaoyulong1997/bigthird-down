#!/usr/bin/env python
"""
=================================
Path with L1- Logistic Regression
=================================
Computes path on IRIS dataset.
"""
print(__doc__)

# Author: Alexandre Gramfort <alexandre.gramfort@inria.fr>
# License: BSD 3 clause
## 基于二项logistic regression 的鸢尾花分类(两类别)
## 1.导入必要的算法包
#  (1)导入datatime模块的datatime类，用于日期和时间的处理
## (2)scikit-learn依赖于NumPy和 matplotlib。
#     导入python Numpy包(主要用于数组及数组操作，常用矩阵运算)，并以np为别名
#      Numpy含各种子包,想了解，可以：dir(np)
#  (3)导入python matplotlib包(2D图像的绘图工具包,常用语数据可视化)的子包pyplot
#     用于数据的可视化，并以plt为别名，了解该子包内容，可以dir(plt)
from datetime import datetime
import numpy as np
import matplotlib.pyplot as plt


## (4)由sklearn导入linear_model模块，用于各种线性模型的实现
#  (5)导入datasets模块
#  (6)由sklearn的SVM模块导入l1_min_c类
from sklearn import linear_model
from sklearn import datasets
from sklearn.svm import l1_min_c


## 2(1)获取iris数据集，提取样本集的输入部分及类别信息：X：150*4;y:150
iris = datasets.load_iris()
X = iris.data
y = iris.target

## 2(2)从数据集中，提取类别号0,1的样本 100*4,100
X = X[y != 2]
y = y[y != 2]

## 2(3)对样本去均值:沿纵向计算均值
X -= np.mean(X, 0)

## 3 用于l1-penalized logistic regression 模型的惩罚系数备选值
#    的设置设置：0.0143*{10^0,...,}
# logspace(start, stop, num=50, endpoint=True, base=10.0, dtype=None)
cs = l1_min_c(X, y, loss='log') * np.logspace(0, 3)

## 4.参数选择开始
print("Computing regularization path ...")

## 4-1. 获取一个 DateTime 对象，该对象设置为此计算机上的
#       当前日期和时间，表示为本地时间。在中国就是北京时间
start = datetime.now()

## 4-2.初始化一个L1-LogisticRegression分类模型实例
# C : float, default: 1.0
#     Inverse of regularization strength; must be a positive float. Like in support vector machines,
#     smaller values specify stronger regularization
#     见scikit-learn 手册 1574页、163页
clf = linear_model.LogisticRegression(C=1.0, penalty='l1', tol=1e-6)

## 4-3 考察不同的C值学习得到的logistics regression 模型的权向量
#      Coefficient of the features in the decision function
#      以及所需的时间
coefs_ = []
for c in cs:
    clf.set_params(C=c)
    clf.fit(X, y)
    coefs_.append(clf.coef_.ravel().copy())
print("This took ", datetime.now() - start)

## 4-4 将50个特征权向量，以4条折线形式可视化
coefs_ = np.array(coefs_)
plt.plot(np.log10(cs), coefs_)
ymin, ymax = plt.ylim()

plt.legend(['1', '2','3','4'])
plt.xlabel('log(C)')
plt.ylabel('Coefficients')
plt.title('Logistic Regression Path')
plt.axis('tight')

plt.show()

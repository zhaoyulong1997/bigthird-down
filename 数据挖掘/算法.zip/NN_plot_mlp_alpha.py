"""
================================================
Varying regularization in Multi-layer Perceptron
================================================
面向两类别分类问题，基于三个人工合成数据集，实现基于多层感知器
分类模型的二维特征空间划分

本例子在于考察分类模型学习使用的目标函数的正则项的控制参数alpha
取值的大小对模型学习的影响.
The plot shows that different alphas yield different
decision functions.

Alpha is a parameter for regularization term, aka penalty term, that combats
overfitting by constraining the size of the weights. 

Increasing alpha may fix high variance (a sign of overfitting) by encouraging
smaller weights, resulting in a decision boundary plot that appears with lesser
curvatures.
Decreasing alpha may fix high bias (a sign of underfitting) by encouraging larger
weights, potentially resulting in a more complicated decision boundary.
"""
print(__doc__)


# Author: Issam H. Laradji
# License: BSD 3 clause

## 基于多层感知器的分类
## 1.导入必要的算法包
#  (1)scikit-learn依赖于NumPy和 matplotlib。
#  导入python Numpy包(主要用于数组及数组操作，常用矩阵运算)，并以np为别名
#  Numpy含各种子包,想了解，可以：dir(np)
#  (2)导入python matplotlib包(2D图像的绘图工具包,常用语数据可视化)的子包pyplot
#  用于数据的可视化，并以plt为别名
#  了解该子包内容，可以dir(plt)
#  (3)导入颜色映射表，以实现数值的伪彩色映射
import numpy as np
from matplotlib import pyplot as plt
from matplotlib.colors import ListedColormap


#  (4)由sklearn的模型选择模块导入train_test_split接口类
#  (5)由sklearn的预处理模块导入StandardScaler类
#  (6)由sklearn的datasets模块加载小型数据集moons，circles，并加载make_classification类
#  (7)由sklearn的neural_network模块导入MLPClassifier类
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.datasets import make_moons, make_circles, make_classification
from sklearn.neural_network import MLPClassifier


## 2(1)设置step size in the mesh
h = .02

## 2(2)生成数组，数组内各元素的对数从-5开始，不超过5
#    例： 10^(-5)，10^(-2),...
alphas = np.logspace(-5, 3, 5)

## 2(3)生成参数取值列表names,列表中各元素为字符串
names = []
for i in alphas:
    names.append('alpha ' + str(i))

## 2(4)生成多层感知器分类模型实例列表
#   列表中每个元素为一个初始化的多层感知器类别实例
classifiers = []
for i in alphas:
    classifiers.append(MLPClassifier(alpha=i, random_state=1))

## 3(1)Generate a random 2-class classification problem.
#  每个类别含一个正态分布的簇
# 返回的数据集：X--100行*2列的样本集(默认样本数100，默认类别数2)
#              y--100行*1列，各样本类别标号
X, y = make_classification(n_features=2, n_redundant=0, n_informative=2,
                           random_state=0, n_clusters_per_class=1)

## 3(2)初始化随机数发生器的状态；生成100行*2列的0~2均匀分布随机数；以此改变X数据集
rng = np.random.RandomState(2)
X += 2 * rng.uniform(size=X.shape)

## 3(3)构成二元组linearly_separable
linearly_separable = (X, y)

## 4 面向两类别分类，得到以二元组方式描述的每个分类问题的数据集；
#    三个二元组构成列表datasets 
#(1)make_moons(noise=0.3, random_state=0)
#   Make two interleaving half circles (默认100*2)
#   附加的高斯白噪声的标准偏差0.3
#(2)make_circles(noise=0.2, factor=0.5, random_state=1)
#   Make a large circle containing a smaller circle in 2d
#   附加的高斯随机白噪声的标准偏差0.2
#(3)linearly_separable
datasets = [make_moons(noise=0.3, random_state=0),
            make_circles(noise=0.2, factor=0.5, random_state=1),
            linearly_separable]

## 5.创建一个指定大小的空的图形窗口
figure = plt.figure(figsize=(17, 9))

## 6. iterate over datasets
## 6-1 初始化计数器
i = 1

## 6-2 针对datasets列表中的每个人工合成数据集
for X, y in datasets:
    
    ## (1) preprocess dataset, split into training and test part
    X = StandardScaler().fit_transform(X)
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=.4)

    ## (2)获取数据集各特征取值的范围
    x_min, x_max = X[:, 0].min() - .5, X[:, 0].max() + .5
    y_min, y_max = X[:, 1].min() - .5, X[:, 1].max() + .5
    
    ## (3)基于该数据集的特征取值情况，将特征空间网格化，得到每个格点的两个特征取值
    xx, yy = np.meshgrid(np.arange(x_min, x_max, h),
                         np.arange(y_min, y_max, h))

    ## (4) 初始化两个颜色表cm,cm_bright
    cm = plt.cm.RdBu
    cm_bright = ListedColormap(['#FF0000', '#0000FF'])
           
    ## (5) 先绘制数据集--just plot the dataset first 
    # 将绘图区域分成3*6=18个小区域，选择第i个子图区域ax
    # 在指定的子图区域ax处绘制当前数据集的训练样本点                   
    ax = plt.subplot(len(datasets), len(classifiers) + 1, i)
    ax.scatter(X_train[:, 0], X_train[:, 1], c=y_train, cmap=cm_bright)
    
    ## (6)同时在该子图区域绘制 Plot the testing points
    ax.scatter(X_test[:, 0], X_test[:, 1], c=y_test, cmap=cm_bright, alpha=0.6)
    
    ## (7)设置绘图效果
    ax.set_xlim(xx.min(), xx.max())
    ax.set_ylim(yy.min(), yy.max())
    ax.set_xticks(())
    ax.set_yticks(())
    
    ## (8)更新计数器
    i += 1

    ## (9) iterate over classifiers
    # 将names与classifiers两个列表打包，合并成二元组方式的列表
    # 对于列表中每个元素(name,clf)
    for name, clf in zip(names, classifiers):
        
        ## 9a 将绘图区域分成3*6=18个小区域，选择第i个子图区域ax
        ax = plt.subplot(len(datasets), len(classifiers) + 1, i)
        
        ## 9b 按照指定的alpha参数，学习分类模型
        clf.fit(X_train, y_train)
        
        ## 9c基于该分类模型，对测试样本集预测，得到预测正确率
        score = clf.score(X_test, y_test)

        ## 9d 获取各格子点处的预测概率
        #     Plot the decision boundary. For that, we will assign a color to each
        #     point in the mesh [x_min, x_max]x[y_min, y_max].
        if hasattr(clf, "decision_function"):
            Z = clf.decision_function(np.c_[xx.ravel(), yy.ravel()])
        else:
            Z = clf.predict_proba(np.c_[xx.ravel(), yy.ravel()])[:, 1]

        ## 9e Put the result into a color plot
        # 绘制填充颜色的二维等高线图
        Z = Z.reshape(xx.shape)
        ax.contourf(xx, yy, Z, cmap=cm, alpha=.8)

        ## 9f 绘制训练样本点 --Plot also the training points
        ax.scatter(X_train[:, 0], X_train[:, 1], c=y_train, cmap=cm_bright,
                   edgecolors='black', s=25)
        
        ## 9g 绘制测试样本点-- testing points
        ax.scatter(X_test[:, 0], X_test[:, 1], c=y_test, cmap=cm_bright,
                   alpha=0.6, edgecolors='black', s=25)
        ## 9h 设置绘图效果
        ax.set_xlim(xx.min(), xx.max())
        ax.set_ylim(yy.min(), yy.max())
        ax.set_xticks(())
        ax.set_yticks(())
        
        ## 9i 绘图区域的名称
        ax.set_title(name)
        
        ## 9j 在当前绘图区域右下角，以指定格式显示预测正确率
        ax.text(xx.max() - .3, yy.min() + .3, ('%.2f' % score).lstrip('0'),
                size=15, horizontalalignment='right')
        
        ## 9k 更新计数器
        i += 1

## 6-3 设定绘图各区域间距    
figure.subplots_adjust(left=.02, right=.98)

## 7显示结果、保存
plt.show()


"""
=====================================
Visualization of MLP weights on MNIST
=====================================

Sometimes looking at the learned coefficients of a neural network can provide
insight into the learning behavior. 

For example if weights look unstructured,maybe some were not used at all, or 
if very large coefficients exist, maybe regularization was too low or the   
learning rate too high.

This example shows how to plot some of the first layer weights in a 
MLPClassifier trained on the MNIST dataset.

The input data consists of 28x28 pixel handwritten digits, leading to 784
features in the dataset. 

Therefore the first layer weight matrix have the shape
(784, hidden_layer_sizes[0]).  

We can therefore visualize a single column of the weight matrix as a 28x28 
pixel image.

To make the example run faster, we use very few hidden units, and train only
for a very short time. Training longer would result in weights with a much
smoother spatial appearance.
"""
print(__doc__)

## 基于多层感知器的手写体数字识别
## 1.导入必要的算法包
#  (1)导入python matplotlib包(2D图像的绘图工具包,常用语数据可视化)的子包pyplot
#     用于数据的可视化，并以plt为别名，了解该子包内容，可以dir(plt)
#  (2)由sklearn的datasets模块加载获取大型多类别数据集接口函数 fetch_mldata
#  参见：https://www.cnblogs.com/zhuyuanhao/p/5383628.html 
#  (3)由sklearn的neural_network模块导入MLPClassifier类
import matplotlib.pyplot as plt
from sklearn.datasets import fetch_mldata
from sklearn.neural_network import MLPClassifier

## 2.获取MINIST数据集
## 关于数据集的获取方式可以多种
#   自带的小数据集（packaged dataset）：sklearn.datasets.load_<name>
#   可在线下载的数据集（Downloaded Dataset）：sklearn.datasets.fetch_<name>
#   计算机生成的数据集（Generated Dataset）：sklearn.datasets.make_<name>
#   svmlight/libsvm格式的数据集:sklearn.datasets.load_svmlight_file(...)
#   从data.org处，在线下载获取的数据集:sklearn.datasets.fetch_mldata(...)
# 从指定地址处，下载指定名称多类别大型数据集
# fetch_mldata(dataname, target_name='label', data_name='data', transpose_data=True, data_home=None)：
# 默认 从 mldata.org 中下载数据集

mnist = fetch_mldata("MNIST original")
mnist

## 3.数据集的预处理；训练集与测试集的划分
# rescale the data, use the traditional train/test split
# X--70000*784  y--70000 {0,1,2,3,4,5,6,7,8,9}
X, y = mnist.data / 255., mnist.target
X_train, X_test = X[:60000], X[60000:]
y_train, y_test = y[:60000], y[60000:]

## 4.初始化MLP分类模型实例；基于训练集，进行mlp的学习
# http://scikit-learn.org/dev/modules/generated/sklearn.neural_network.MLPClassifier.html
# (1) hidden_layer_sizes : tuple, length = n_layers - 2, default (100,)
# (2)activation : {‘identity’, ‘logistic’, ‘tanh’, ‘relu’}, default ‘relu’
#    Activation function for the hidden layer.
#   ‘identity’, no-op activation, useful to implement linear bottleneck, returns f(x) = x
#   ‘logistic’, the logistic sigmoid function, returns f(x) = 1 / (1 + exp(-x)).
#   ‘tanh’, the hyperbolic tan function, returns f(x) = tanh(x).
#   ‘relu’, the rectified linear unit function, returns f(x) = max(0, x)
# (3)solver : {‘lbfgs’, ‘sgd’, ‘adam’}, default ‘adam’
#    The solver for weight optimization.
#   ‘lbfgs’ is an optimizer in the family of quasi-Newton methods.
#   ‘sgd’ refers to stochastic gradient descent.
#   ‘adam’ refers to a stochastic gradient-based optimizer proposed by Kingma, Diederik, and Jimmy Ba
#   Note: The default solver ‘adam’ works pretty well on relatively large datasets (with thousands of training samples or more) in terms of both training time and validation score. For small datasets, however, ‘lbfgs’ can converge faster and perform better.
# (4)alpha : float, optional, default 0.0001
#    L2 penalty (regularization term) parameter.
# (5)batch_size : int, optional, default ‘auto’
#    Size of minibatches for stochastic optimizers. 
#    If the solver is ‘lbfgs’, the classifier will not use minibatch. 
#    When set to “auto”, batch_size=min(200, n_samples)
# (6)learning_rate : {‘constant’, ‘invscaling’, ‘adaptive’}, default ‘constant’
#    Learning rate schedule for weight updates.
#   ‘constant’ is a constant learning rate given by ‘learning_rate_init’.
#   ‘invscaling’ gradually decreases the learning rate learning_rate_ at each time step ‘t’ using an inverse scaling exponent of ‘power_t’. effective_learning_rate = learning_rate_init / pow(t, power_t)
#   ‘adaptive’ keeps the learning rate constant to ‘learning_rate_init’ as long as training loss keeps decreasing. 
#   Each time two consecutive epochs fail to decrease training loss by at least tol, or fail to increase validation score by at least tol if ‘early_stopping’ is on, 
#   the current learning rate is divided by 5.Only used when solver='sgd'.
# (7)learning_rate_init : double, optional, default 0.001
#   The initial learning rate used. It controls the step-size in updating the weights. 
#   Only used when solver=’sgd’ or ‘adam’.
# (8)power_t : double, optional, default 0.5
#   The exponent for inverse scaling learning rate. 
#   It is used in updating effective learning rate when the learning_rate is set to ‘invscaling’. Only used when solver=’sgd’.
# (9)max_iter : int, optional, default 200
#   Maximum number of iterations. The solver iterates until convergence (determined by ‘tol’) or this number of iterations. 
#   For stochastic solvers (‘sgd’, ‘adam’), note that this determines the number of epochs (how many times each data point will be used), 
#   not the number of gradient steps.
# (10)shuffle : bool, optional, default True
#  Whether to shuffle samples in each iteration. Only used when solver=’sgd’ or ‘adam’.
# (11)random_state : int, RandomState instance or None, optional, default None
#  If int, random_state is the seed used by the random number generator; 
#  If RandomState instance, random_state is the random number generator; 
#  If None, the random number generator is the RandomState instance used by np.random.
# (12)tol : float, optional, default 1e-4
#  Tolerance for the optimization. 
#  When the loss or score is not improving by at least tol for n_iter_no_change consecutive iterations, 
#  unless learning_rate is set to ‘adaptive’, convergence is considered to be reached and training stops.
# (13)verbose : bool, optional, default False
#  Whether to print progress messages to stdout.
# (14)warm_start : bool, optional, default False
#  When set to True, reuse the solution of the previous call to fit as initialization, otherwise, just erase the previous solution. 
#  See the Glossary.
# (15)momentum : float, default 0.9
# Momentum for gradient descent update. Should be between 0 and 1. 
# Only used when solver=’sgd’.
# (16)nesterovs_momentum : boolean, default True
# Whether to use Nesterov’s momentum. Only used when solver=’sgd’ and momentum > 0.
# (17)early_stopping : bool, default False
# Whether to use early stopping to terminate training when validation score is not improving. 
# If set to true, it will automatically set aside 10% of training data as validation and 
# terminate training when validation score is not improving by at least tol for n_iter_no_change consecutive epochs. 
# Only effective when solver=’sgd’ or ‘adam’
# (18)validation_fraction : float, optional, default 0.1
# The proportion of training data to set aside as validation set for early stopping. 
# Must be between 0 and 1. Only used if early_stopping is True
# (19)beta_1 : float, optional, default 0.9
# Exponential decay rate for estimates of first moment vector in adam, should be in [0, 1). 
# Only used when solver=’adam’
# (20)beta_2 : float, optional, default 0.999
# Exponential decay rate for estimates of second moment vector in adam, should be in [0, 1). 
# Only used when solver=’adam’
# (21)epsilon : float, optional, default 1e-8
#  Value for numerical stability in adam. Only used when solver=’adam’
# (22)n_iter_no_change : int, optional, default 10
#  Maximum number of epochs to not meet tol improvement. Only effective when solver=’sgd’ or ‘adam’
# New in version 0.20.
# ---------------------------------------------------
# mlp = MLPClassifier(hidden_layer_sizes=(100, 100), max_iter=400, alpha=1e-4,
#                     solver='sgd', verbose=10, tol=1e-4, random_state=1)
mlp = MLPClassifier(hidden_layer_sizes=(50,), max_iter=50, alpha=1e-4,
                    solver='sgd', verbose=50, tol=1e-4, random_state=1,
                    learning_rate_init=.1)

mlp.fit(X_train, y_train)

## 5.基于学习得到的MLP，对训练集、测试集预测得到预测正确率
print("Training set score: %f" % mlp.score(X_train, y_train))
print("Test set score: %f" % mlp.score(X_test, y_test))

## 6.构造图形窗口，获取各绘图子区域id号
fig, axes = plt.subplots(4, 4)


## 7.获取多层感知器第1隐含层与输入层各节点连接参数的最大、最小值
# use global min / max to ensure all weights are shown on the same scale
vmin, vmax = mlp.coefs_[0].min(), mlp.coefs_[0].max()

## 8.将多层感知器隐含层与输入层的连接参数矩阵784*50 转置，得到50*784
for coef, ax in zip(mlp.coefs_[0].T, axes.ravel()):
    ax.matshow(coef.reshape(28, 28), cmap=plt.cm.gray, vmin=.5 * vmin,
               vmax=.5 * vmax)
    ax.set_xticks(())
    ax.set_yticks(())

## 9.显示绘图结果
plt.show()
